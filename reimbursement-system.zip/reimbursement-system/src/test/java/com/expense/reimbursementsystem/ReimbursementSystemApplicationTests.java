package com.expense.reimbursementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReimbursementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
