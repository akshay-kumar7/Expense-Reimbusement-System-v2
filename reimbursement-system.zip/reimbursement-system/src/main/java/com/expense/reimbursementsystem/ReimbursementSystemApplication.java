package com.expense.reimbursementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReimbursementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReimbursementSystemApplication.class, args);
	}

}
